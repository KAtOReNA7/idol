# 女团项目安全源码交接包

Base SHA: 3f316e72f9c0ae88707bdc23bb65fa983737867c

这是长期工程协作的可构建源码副本，首个完整交付目标为全 51 团大事时间轴。唯一 schema 是 HANDOFF/timeline-event.schema.json。技术任务见同目录 Sol_全51团大事时间轴_技术执行要求.txt。公共资料、51 团路由和产品源码保留；该包不能直接覆盖生产。

## 安全边界
- data/snapshot.json、data/backup.ts、data/snapshot-import.json 全部是新生成的纯合成演示数据，未复制真实用户的评分、备注、观看状态或附件信息。51 个公开团体路由 ID 保留，成员、作品、关系均使用 recHandoff 合成 ID。
- 740 张静态图片均为从零绘制并醒目标识的合成占位图，路径/格式保留以维持运行，不是原图遗失。真实原图、display 图均未发出；image-placeholder-manifest.json 记录真实素材指纹以供内部整合，严禁把占位图发布或回传覆盖。
- 不含 .git、.env、凭证、运行导出、依赖、dist、缓存或私人快照。hosting project、飞书 base/table 标识为沙盒占位，不得连生产或创建新凭证。
- 公开 metadata 中的音乐节目分数、来源注释不等于用户个人评分；测试 fixtures 的评分/备注均为合成样例。

## 文件责任与禁止范围
- Sol 负责 artist 专页组件、全团 timeline 共用组件/helper/schema 校验与合成测试；保持现有团体风格与默认关系。
- dot 当前独占个人记录检索：禁止 Sol 修改 app/page.tsx、lib/idol/journey.ts、components/use-browse-journey.ts，以及个人记录数据接口（app/api 下的个人/目录/评分/备注/观看/保存接口及对应 lib/idol/catalog、save、native-save、native-reader、live、feishu 等数据读写层）。
- 时间轴导航应使用 artist 专页导航/历史返回机制，不改上述全局 journey。若时间轴确实需要这些文件或以上接口改动，先在报告中说明必要性和精确文件/最小改动，交 dot 决定，不能自行修改。
- Astra 独占 data/artist-timelines 的真实事件数据与来源证据。Sol 只读集成；仅在 tests/fixtures/timeline 下创建合成时间轴数据。禁止把示例文件误当真实增量上线。
- 不改用户评分、备注、观看、照片来源绑定、历史成员关系，不扩大分享，不部署、不推送、不向生产或第三方上传，不新增权限或凭证。

## 安装、运行、验证
建议 Node >=22.13。首次运行 npm ci（或项目既有 npm run install:ci），随后 npm run dev。无需任何账号/生产凭证，运行时使用合成只读 snapshot。使用页面展示的本地地址。

node node_modules/typescript/bin/tsc --noEmit --incremental false
npm run build
node HANDOFF/run-safe-tests.mjs
node HANDOFF/smoke-fixture.cjs

实际验证结果见 VALIDATION.json 和 TEST_SCOPE.md。原始全套中依赖真实快照或图片字节的测试不能在这个包上作为生产验收；不得因此放宽产品安全校验。

## 回传要求
1. 在你自己的解包目录建立本地 Git 基线，完整记录交接输入，再只提交本次功能修改；不要把 .git 归档发送。
2. 回传相对该安全基线的 unified patch（包含新增的源码/合成测试），另附改动文件清单、运行命令/结果、已知限制与截图。声明 base SHA 为上述生产基线并给出输入压缩包 SHA-256。
3. 禁止回传任何 data/snapshot.json、data/backup.ts、data/snapshot-import.json、public 占位图、.openai/hosting.json、沙盒 identifier 替换、HANDOFF 验证清单本身、node_modules、dist、.env 或凭证改动。尤其不能发送整个安全副本要求覆盖生产。
4. data/*artist.json 等公开事实与来源默认只读，不用编码方便为由改日期、关系或制造事件；实际时间轴事实由 Astra 提供。
5. 若需修改一个被沙盒替换的源码文件，应只回传功能 hunks，并明确说明沙盒标识须由 dot 保留生产原值；不得夹带替换。
6. dot 审核后在真实主线上应用、全套测试、图片/历史关系检查和发布。Sol 不自行部署。

## 交付与接续节奏
用户亲自发送本任务指令后，可将本任务的最小 patch、合成 fixture 源码、报告和必要截图组成 ZIP，保存到当前会话资料库，并返回真实文件 ID/附件。这里的“不上传”是禁止向生产或第三方上传，不禁止上述明确授权的当前会话交付；工具若另需批准，仍须遵守，不猜造文件 ID，也不要求绕过审批。

白天由 Astra、Sol、dot 按文件责任并行推进；北京时间凌晨由 dot 独立接续其已获授权的部分。Sol 每次完成或暂停时，必须交可复现检查点：输入 base/hash、最小 patch、精确命令与结果、已完成和未完成模块、阻塞点及下一步。不得静默交出半成品或同时占用同一共享文件。该协作节奏不授权任何新定时任务，不新增提醒/自动化。
