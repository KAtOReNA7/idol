# Handoff test scope

The unfiltered original suite was executed against this safe package: 961 tests, 917 passed, 44 failed because the package intentionally omits real snapshot identities/history, real photographs and deployment identifiers. These are not a claimed all-green production result.

Run `node HANDOFF/run-safe-tests.mjs` for the applicable handoff regression suite. It skips only the exact 44 known production-dependent test names listed in production-only-test-names.json; all other existing and new tests run normally. Do not delete or weaken tests to make production green. Production integration must rerun the full suite against the real protected source and reviewed assets in dot's environment.

Three core.test.cjs production-oracle bodies (snapshot score/count totals, queue counts, source gaps) are replaced with explicit skipped stubs because their expected values encode the user's private viewing/rating aggregates. The rest of the original test cases are preserved, except sandbox identifier substitutions recorded in the replacement manifest.

Historical member counts 12/6/9 are not represented by the synthetic runtime snapshot. Add wholly synthetic history fixtures to test that logic; do not request or manufacture the real private snapshot. Do not replace original product assertions on return.
