import {readdirSync,readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const names=JSON.parse(readFileSync(new URL('./production-only-test-names.json',import.meta.url),'utf8'));
const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const skip='^(?:'+names.map(escape).join('|')+')$';
const files=readdirSync('tests').filter(n=>/\.test\.(cjs|mjs)$/.test(n)).map(n=>'tests/'+n);
const result=spawnSync(process.execPath,['--test','--test-skip-pattern='+skip,...files],{stdio:'inherit'});
process.exit(result.status??1);
