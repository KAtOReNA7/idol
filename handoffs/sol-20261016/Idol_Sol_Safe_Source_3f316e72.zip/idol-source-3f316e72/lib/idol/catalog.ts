import snapshot from '@/data/snapshot.json';
import {F} from './fields';
import {groupPlaceholderFor,wasAuditedGroupPlaceholder} from './placeholders';
import {stageSupplementForWork} from './supplements';
import {stageForWork,stageResearchForWork} from './stage';
import {asText,asNumber,asIds,asUrl,videoId} from './values';
import {configured,TableKey} from './feishu';
import {liveTables} from './live';
import type {Catalog,Photo,StageResearch} from './types';
type Row={recordId:string;fields:Record<string,unknown>};
export type Tables=Record<TableKey,{records:Row[]}>;
function photo(table:'members'|'ratings',r:Row,fieldId:string,works:Row[]):Photo|null{const raw=r.fields[fieldId];if(!Array.isArray(raw)||!raw.length)return null;const recognition=asText(r.fields[F.ratings.recognition]);return {table,recordId:r.recordId,fieldId,index:0,...(table==='ratings'&&raw[0].source_kind==='mv_still'&&/^native_photo_[a-f0-9]{64}$/.test(raw[0].file_token)&&typeof raw[0].member_id==='string'&&typeof raw[0].work_id==='string'&&typeof raw[0].exact_video_id==='string'&&videoId(asUrl(works.find(w=>w.recordId===raw[0].work_id)?.fields[F.works.url]))===raw[0].exact_video_id?{nativeIdentity:{memberId:raw[0].member_id,workId:raw[0].work_id,videoId:raw[0].exact_video_id}}:{}),kind:table==='ratings'&&raw[0].source_kind==='mv_still'?'本 MV 截图':table==='ratings'?(recognition.includes('全员拼图')?'本 MV 具名全员拼图':recognition.includes('粉丝')?'粉丝具名 MV 截图':'本 MV 认人图'):undefined};}
function date(v:unknown){if(typeof v==='number'){try{return new Date(v).toISOString().slice(0,10);}catch{return '';}}return asText(v).replace(/T.*$/,'');}
export function projectCatalog(t:Tables,mode:'snapshot'|'live',capturedAt:string,warning:string|null=null):Catalog{
 const members=t.members.records.map(r=>{const v=r.fields;const f=F.members;return {id:r.recordId,name:asText(v[f.name]),cnName:asText(v[f.cnName]),stageName:asText(v[f.stageName]),groupIds:asIds(v[f.groups]),formerGroupIds:asIds(v[f.formerGroups]),photo:photo('members',r,f.photo,t.works.records),favorite:asNumber(v[f.favorite]),note:asText(v[f.note]),profile:asText(v[f.profile]),status:asText(v[f.status]),country:asText(v[f.country]),role:asText(v[f.role]),officialUrl:asUrl(v[f.officialUrl]),birthDate:date(v[f.birthDate])};});
 const ratings=t.ratings.records.map(r=>{const v=r.fields;const f=F.ratings;return {id:r.recordId,name:asText(v[f.name]),memberIds:asIds(v[f.members]),workIds:asIds(v[f.works]),score:asNumber(v[f.score]),stylingScore:asNumber(v[f.stylingScore]),memory:asText(v[f.memory]),note:asText(v[f.note]),photo:photo('ratings',r,f.photo,t.works.records),verification:asText(v[f.verification]),source:asUrl(v[f.source]),recognition:asText(v[f.recognition])};});
 const works=t.works.records.map(r=>{const v=r.fields;const f=F.works;const ratingIds=ratings.filter(x=>x.workIds.includes(r.recordId)).map(x=>x.id);const placeholder=groupPlaceholderFor(r,ratingIds);const research=stageResearchForWork(r.recordId);const stageResearch:StageResearch=!placeholder&&wasAuditedGroupPlaceholder(r.recordId)&&research.status==='missing_song_identity'?{status:'pending',reason:'这条原占位记录资料已变化，已恢复展示；作品身份和舞台来源需重新核验。',checkedAt:null}:research;return {placeholder,stageSupplement:stageSupplementForWork(r.recordId),stage:stageForWork(r.recordId),stageResearch,id:r.recordId,name:asText(v[f.name]),song:asText(v[f.song]),groupIds:asIds(v[f.groups]),url:asUrl(v[f.url]),score:asNumber(v[f.score]),stageScore:asNumber(v[f.stageScore]),note:asText(v[f.note]),watched:asText(v[f.watched]),videoType:asText(v[f.videoType]),version:asText(v[f.version]),releaseDate:date(v[f.releaseDate]),verification:asText(v[f.verification]),officialTitle:asText(v[f.officialTitle]),channel:asText(v[f.channel]),ratingIds,source:asText(v[f.source])};});
 const groups=t.groups.records.map(r=>{const v=r.fields;const f=F.groups;const gw=works.filter(w=>w.groupIds.includes(r.recordId));const rated=gw.filter(w=>w.score!==null);return {id:r.recordId,name:asText(v[f.name]),generation:asText(v[f.generation]),company:asText(v[f.company]),country:asText(v[f.country]),note:asText(v[f.note]),debut:date(v[f.debut]),currentName:asText(v[f.currentName]),status:asText(v[f.status]),officialUrl:asUrl(v[f.officialUrl]),channelUrl:asUrl(v[f.channelUrl]),memberIds:members.filter(m=>m.groupIds.includes(r.recordId)).map(m=>m.id),workIds:gw.map(w=>w.id),average:rated.length?rated.reduce((n,w)=>n+w.score!,0)/rated.length:null,ratedCount:rated.length};});
 const rated=works.filter(x=>x.score!==null);return {mode,capturedAt,loadedAt:new Date().toISOString(),warning,groups,members,works,ratings,counts:{groups:groups.length,members:members.length,works:works.length,ratings:ratings.filter(r=>r.memberIds.length>0&&r.workIds.length>0).length,ratedWorks:rated.length,scoreSum:rated.reduce((n,w)=>n+w.score!,0)}};
}
// In-isolate coalescing still guards superseded reads. Durable snapshots use the raw
// tables so each deployment always projects its current stage/source metadata.
const CATALOG_CACHE_MS=5*60*1000;
export type CatalogSnapshot={tables:Tables;capturedAt:string;catalog:Catalog};
let generation=0;
let cache:{at:number;generation:number;snapshot:CatalogSnapshot}|null=null;
let pending:{generation:number;promise:Promise<CatalogSnapshot>}|null=null;
export function invalidateCatalog(){generation++;cache=null;}
export async function getCatalogSnapshot(force=false):Promise<CatalogSnapshot>{
 if(!configured()){const tables=snapshot.tables as Tables;return {tables,capturedAt:snapshot.capturedAt,catalog:projectCatalog(tables,'snapshot',snapshot.capturedAt,'飞书连接待完成。当前为只读迁移快照，评分保存尚未开放。')};}
 if(force)invalidateCatalog();
 const current=generation;
 if(cache&&cache.generation===current&&Date.now()-cache.at<CATALOG_CACHE_MS)return cache.snapshot;
 if(pending?.generation===current)return pending.promise;
 const entry={generation:current,promise:null as unknown as Promise<CatalogSnapshot>};
 entry.promise=(async()=>{
  const tables=await liveTables();
  if(current!==generation)return getCatalogSnapshot();
  const capturedAt=new Date().toISOString();
  const snapshot={tables,capturedAt,catalog:projectCatalog(tables,'live',capturedAt)};
  cache={at:Date.now(),generation:current,snapshot};return snapshot;
 })();
 pending=entry;
 try{return await entry.promise;}finally{if(pending===entry)pending=null;}
}
export async function getCatalog(force=false):Promise<Catalog>{return (await getCatalogSnapshot(force)).catalog;}
